#ifndef ENIGME_H_INCLUDED
#define ENIGME_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include "enigme.h"

int enigmee(    SDL_Surface *fenetre_enigme)  ; 


#endif // ENIGME_H_INCLUDED
